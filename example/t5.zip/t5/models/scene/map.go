package scene

import (
	"fmt"
	"image/color"
	"log"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"github.com/myanagisawa/ebitest/example/t5/enum"
	"github.com/myanagisawa/ebitest/example/t5/interfaces"
	"github.com/myanagisawa/ebitest/example/t5/models/control"
	"github.com/myanagisawa/ebitest/example/t5/models/layer"
)

var (
	dbg string
)

type (
	// Map ...
	Map struct {
		Base
	}
)

// NewMap ...
func NewMap(m interfaces.GameManager) *Map {

	s := &Map{
		Base: Base{
			label: "Map",
		},
	}

	l := layer.NewMapLayer("Layer1", g.Images["world"], s, g.NewScale(1.5, 1.5), nil, 0, false)
	l.Sites = m.GetSites()
	l.Routes = m.GetRoutes(l.Sites)
	s.SetLayer(l)
	c := control.NewButton("menu", l, g.Images["btnBase"], g.Fonts["btnFont"], color.Black, 500, 500)
	l.AddUIControl(c)
	l.EventHandler().AddEventListener(c, "click", func(target interfaces.UIControl, scene interfaces.Scene, point *g.Point) {
		log.Printf("%s clicked", target.Label())
		m.TransitionTo(enum.MainMenuEnum)
	})

	return s
}

// Update ...
func (s *Map) Update() error {
	et := GetEdgeType(ebiten.CursorPosition())
	if et != enum.EdgeTypeNotEdge {
		s.layers[0].Scroll(et)
	}

	s.activeLayer = s.LayerAt(ebiten.CursorPosition())
	if s.activeLayer != nil {
		// log.Printf("activeLayer: %#v", s.activeLayer.Label())
		if inpututil.IsMouseButtonJustReleased(ebiten.MouseButtonLeft) {
			x, y := ebiten.CursorPosition()
			// click イベントを発火
			s.activeLayer.EventHandler().Firing(s, "click", x, y)
		}
	}

	for _, layer := range s.layers {
		layer.Update()
	}

	return nil
}

// Draw ...
func (s *Map) Draw(screen *ebiten.Image) {

	for _, layer := range s.layers {
		layer.Draw(screen)
	}

	active := " - "
	control := " - "
	if s.activeLayer != nil {
		eo := s.activeLayer.EbiObjects()[0]
		px, py := eo.GlobalPosition().Get()
		active = fmt.Sprintf("%s: (%d, %d)", s.activeLayer.LabelFull(), int(px), int(py))
		c := s.activeLayer.UIControlAt(ebiten.CursorPosition())
		if c != nil {
			px, py = c.EbiObjects()[0].GlobalPosition().Get()
			control = fmt.Sprintf("%s: (%d, %d)", c.Label(), int(px), int(py))
		}
	}

	x, y := ebiten.CursorPosition()
	dbg := fmt.Sprintf("%s\nTPS: %0.2f\nFPS: %0.2f\npos: (%d, %d)\nactive:\n - layer: %s\n - control: %s", printMemoryStats(), ebiten.CurrentTPS(), ebiten.CurrentFPS(), x, y, active, control)
	// dbg = fmt.Sprintf("%s", printMemoryStats())
	ebitenutil.DebugPrint(screen, dbg)
}
